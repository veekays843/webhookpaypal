const express = require("express");
const bodyParser = require("body-parser");
const admin = require("firebase-admin");

const serviceAccountJSON = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;

if (!serviceAccountJSON) {
  console.error("Missing FIREBASE_SERVICE_ACCOUNT_JSON environment variable");
  process.exit(1);
}

const serviceAccount = JSON.parse(serviceAccountJSON);

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

const app = express();
app.use(bodyParser.json());

const PAYPAL_WEBHOOK_ID = process.env.PAYPAL_WEBHOOK_ID || "YOUR_WEBHOOK_ID";

app.post("/webhook", (req, res) => {
  const event = req.body;
  const eventType = event.event_type;

  console.log("Received PayPal Event:", eventType);

  if (eventType === "PAYMENT.CAPTURE.COMPLETED") {
    const transactionId = event.resource.id;
    const amount = event.resource.amount.value;
    const payerEmail = event.resource.payer.email_address;

    db.collection("payments").add({
      transactionId,
      amount,
      payerEmail,
      receivedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    console.log("Payment recorded in Firestore.");
  }

  res.sendStatus(200);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
